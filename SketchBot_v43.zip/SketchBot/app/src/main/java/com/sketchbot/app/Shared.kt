package com.sketchbot.app

import android.graphics.PointF

/** مرحلة رسم واحدة: لون واحد وخطوطه ونقطة لأخذ لونه من الصورة المرجعية */
class Phase(
    val color: Int,
    val label: String,
    val strokes: List<List<PointF>>,
    val fast: Boolean,
    val pickX: Float = -1f,
    val pickY: Float = -1f,
    // وضع التعبئة: نقاط الضغط بأداة Fill داخل كل منطقة (null = مرحلة رسم عادية)
    val fills: List<PointF>? = null,
    // مرحلة تنعيم: ضربات Smudge قصيرة عبر الحدود بين الألوان
    val blend: Boolean = false,
    // مساحة كل منطقة تعبئة (بكسل الصورة) وخطوط بديلة بالفرشاة إن لم تكن المنطقة مغلقة
    val fillAreas: List<Float>? = null,
    val fillFallback: List<List<List<PointF>>>? = null,
    // ضربات الفرشاة الكبيرة (داخل المناطق الواسعة)؛ strokes = ضربات الفرشاة الصغيرة (الحواف والخطوط)
    val big: List<List<PointF>> = emptyList(),
    // رقم اللون في خريطة Shared.lbl (للتحقق من التغطية بعد الرسم)
    val cid: Int = -1
)

object Shared {
    @Volatile var phases: List<Phase> = emptyList()
    @Volatile var imgW: Int = 1
    @Volatile var imgH: Int = 1
    // موضع الجزء المحلَّل داخل الصورة الأصلية الكاملة (نِسَب 0..1)
    @Volatile var fx0: Float = 0f
    @Volatile var fy0: Float = 0f
    @Volatile var fw: Float = 1f
    @Volatile var fh: Float = 1f
    @Volatile var aspect: Float = 1f
    // طبقة جديدة لكل لون
    @Volatile var layers: Boolean = true
    // سرعة الرسم (مضاعف): لا تؤثر على بطء تغيير الألوان
    @Volatile var speed: Float = 4f
    // عرض الفرشاتين على الشاشة (بكسل) عند تفعيل التلوين المزدوج؛ 0 = معطّل
    @Volatile var smallPx: Float = 0f
    // خريطة الألوان النهائية (بدقة imgW×imgH): رقم اللون لكل بكسل أو -1
    @Volatile var lbl: IntArray? = null
    @Volatile var bigPx: Float = 0f
}
